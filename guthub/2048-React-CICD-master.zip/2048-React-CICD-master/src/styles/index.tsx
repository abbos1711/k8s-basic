import "./index.less";

/**
 * The pixel size of the grid.
 */
export const pixelSize = 8;
