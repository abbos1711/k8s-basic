package com.cbank.domain.security;

/**
 * @author Podshivalov N.A.
 * @since 21.11.2017.
 */
public enum  BaseTokenType {
    RESET_PASSWORD, REGISTRATION
}
