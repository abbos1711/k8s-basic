package com.cbank.domain.credit;

/**
 * @author Podshivalov N.A.
 * @since 25.11.2017.
 */
public enum CreditDirection {
    CREDIT, DEPOSIT
}
