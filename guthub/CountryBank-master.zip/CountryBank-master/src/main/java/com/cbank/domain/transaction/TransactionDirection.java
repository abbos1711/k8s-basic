package com.cbank.domain.transaction;


public enum TransactionDirection {
    IN, OUT
}
