package com.cbank.domain.credit;


public enum CreditState {
    OPENED, CLOSED
}
