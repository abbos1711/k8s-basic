package com.cbank.exceptions;

/**
 * @author Podshivalov N.A.
 * @since 21.11.2017.
 */
public class TokenExpiredException extends RuntimeException {}
