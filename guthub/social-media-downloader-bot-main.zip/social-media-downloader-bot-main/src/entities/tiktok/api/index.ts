export { getPage } from './tiktopApi';
