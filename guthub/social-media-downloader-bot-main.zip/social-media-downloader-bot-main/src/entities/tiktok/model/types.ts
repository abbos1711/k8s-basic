export interface TiktokLink {
	href?: string;
	title: string;
}
