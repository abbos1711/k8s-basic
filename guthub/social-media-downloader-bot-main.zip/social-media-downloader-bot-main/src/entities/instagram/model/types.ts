export interface InstagramLink {
	type: 'photo' | 'video';
	href: string;
	source: string;
}
