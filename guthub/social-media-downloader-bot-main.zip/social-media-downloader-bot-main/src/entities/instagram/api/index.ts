export { downloadLink, getPage } from './instagramApi';
