export interface YouTubeLink {
	title?: string;
	descr?: string;
	quality: string;
	href: string;
	size: number | null;
}
