import React from "react";
import "./styles.css";

import Tetris from "./components/Tetris";

export default function App() {
  return <Tetris />;
}
