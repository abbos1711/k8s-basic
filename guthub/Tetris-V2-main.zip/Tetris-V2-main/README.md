# React Tetris

> Fully responsive tetris game built with ReactJS

<p align="start">
	  <img alt="GitHub language count" src="https://img.shields.io/github/languages/count/mpirescarvalho/react-tetris?style=flat">
	  <img alt="GitHub top language" src="https://img.shields.io/github/languages/top/mpirescarvalho/react-tetris">
	  <img alt="GitHub stars" src="https://img.shields.io/github/stars/mpirescarvalho/react-tetris?style=social">
	  <img alt="GitHub last commit" src="https://img.shields.io/github/last-commit/mpirescarvalho/react-tetris">
	  <a href="https://mpirescarvalho.github.io/react-tetris/">
			<img alt="Website" src="https://img.shields.io/website?url=https%3A%2F%2Fmpirescarvalho.github.io/react-tetris">
    </a>
</p>

<h1 align="center">
  <img alt="React tetris desktop" title="#React tetris desktop" src="./assets/react-tetris-desktop-1.png" />
  <img width="35%" alt="React tetris mobile 2" title="#React tetris mobile 2" src="./assets/react-tetris-mobile-2.png" />
  <img width="35%" alt="React tetris mobile 1" title="#React tetris mobile 1" src="./assets/react-tetris-mobile-1.png" />
</h1>
